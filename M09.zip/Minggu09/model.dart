import 'package:cloud_firestore/cloud_firestore.dart';

class EventModel {
  String? id;
  String judul;
  String keterangan;
  String tanggal;
  bool islike;
  String pembicara;

  EventModel(
      {this.id,
      required this.judul,
      required this.keterangan,
      required this.tanggal,
      required this.islike,
      required this.pembicara});

  Map<String, dynamic> toMap() {
    return {
      'judul': judul,
      'keterangan': keterangan,
      'pembicara': pembicara,
      'islike': islike,
      'tanggal': tanggal
    };
  }

  EventModel.fromDocSnapshot(DocumentSnapshot<Map<String, dynamic>> doc)
      : id = doc.id,
        judul = doc.data()?['judul'],
        keterangan = doc.data()?['keterangan'],
        pembicara = doc.data()?['pembicara'],
        islike = doc.data()?['islike'],
        tanggal = doc.data()?['tanggal'];
}
